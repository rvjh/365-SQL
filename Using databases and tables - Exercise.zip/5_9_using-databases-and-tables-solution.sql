# Using databases and tables - solution

SELECT * FROM sales;

SELECT * FROM sales.sales;